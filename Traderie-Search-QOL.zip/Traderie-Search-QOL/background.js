// Background processes for your extension can go here if you have any
